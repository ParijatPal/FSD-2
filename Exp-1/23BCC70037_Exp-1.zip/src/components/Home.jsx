export default function Home() {
  return <h2>Welcome to the Home Page</h2>
}