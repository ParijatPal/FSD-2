export default function Contact() {
  return <h2>Welcome to the Contact Page</h2>
}