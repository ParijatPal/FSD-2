import React from 'react';

function Select() {
  return (
    <div>
      <select>
        <option value="">Select an option</option>
        <option value="1">Option 1</option>
        <option value="2">Option 2</option>
      </select>
    </div>
  );
}

export default Select;
