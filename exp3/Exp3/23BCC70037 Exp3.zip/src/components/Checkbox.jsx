import React from 'react';

function Checkbox() {
  return (
    <div>
      <input type="checkbox" id="checkbox" name="checkbox" />
      <label htmlFor="checkbox">Checkbox</label>
    </div>
  );
}

export default Checkbox;
