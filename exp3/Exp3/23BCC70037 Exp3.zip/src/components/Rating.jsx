import React from 'react';

function Rating() {
  return (
    <div>
      {/* Basic rating component */}
      <span>☆</span>
      <span>☆</span>
      <span>☆</span>
      <span>☆</span>
      <span>☆</span>
    </div>
  );
}

export default Rating;
